# Design Guidelines: M.Thanvish Reddy Portfolio

## Design Approach

**Reference-Based Approach**: Drawing inspiration from modern creative portfolios (Brittany Chiang, Bruno Simon, Awwwards winners) with a focus on bold typography, generous whitespace, and thoughtful micro-interactions. The dual-theme concept requires careful consideration of layout that works beautifully in both color and monochrome contexts.

**Core Principle**: Create a portfolio that demonstrates design sophistication while maintaining youthful energy appropriate for a student designer. The color theme should feel dynamic and experimental; the black-and-white theme should feel refined and professional.

---

## Typography System

**Primary Font**: Inter or DM Sans (Google Fonts) - modern, clean, excellent readability
**Accent Font**: Space Grotesk or Clash Display - for hero headlines and section titles

**Hierarchy**:
- Hero Name: text-6xl to text-8xl (96-128px), bold, tight letter-spacing
- Hero Subtitle: text-xl to text-2xl (20-24px), regular weight
- Section Headers: text-4xl to text-5xl (36-48px), semi-bold
- Subsection Headers: text-2xl to text-3xl (24-30px), medium
- Body Text: text-base to text-lg (16-18px), regular
- Captions/Labels: text-sm (14px), medium

---

## Layout & Spacing System

**Tailwind Spacing Units**: Use 4, 8, 12, 16, 20, 24, 32 for consistent rhythm

**Container Strategy**:
- Maximum width: max-w-7xl for content sections
- Generous section padding: py-20 to py-32 on desktop, py-12 to py-16 on mobile
- Horizontal padding: px-6 on mobile, px-8 on tablet, px-12 on desktop

**Grid System**:
- Projects: 2-column grid on tablet (md:grid-cols-2), 3-column on desktop (lg:grid-cols-3)
- Experience cards: Single column stack with timeline indicator on left
- Skills: Multi-column responsive grid (grid-cols-2 md:grid-cols-3 lg:grid-cols-4)

---

## Component Library

### Navigation
- Fixed top navigation with theme toggle prominently placed (top-right)
- Smooth scroll navigation links to sections
- Theme toggle: Sun/Moon icon button with smooth rotation animation on click
- Mobile: Hamburger menu with slide-in drawer

### Hero Section
- Full-height (min-h-screen) with centered content
- Animated name reveal on page load (fade-up, stagger)
- Subtitle: "Graphic Designer & UI/UX Designer" with visual separator (thin line or dot)
- "12th Grade Student" badge styled as a pill with subtle background
- Scroll indicator at bottom (animated bounce)
- NO hero image - focus on typography and gradient backgrounds

### About Section
- Two-column layout: Profile image/avatar placeholder (left) + Bio text (right)
- Skills displayed as pill badges with hover scale effect
- Key skills: Graphic Design, UI Design, UX Design, Branding
- Personality statement emphasizing youth and passion for design

### Experience Section
- Timeline-style layout with vertical line connecting cards
- Two startup experience cards with:
  - Company name (placeholder: "Startup Company Name")
  - Role/Position
  - Duration
  - Key achievements (2-3 bullet points)
  - Tech/tools used (small badges)
- Alternating card positions (left/right on desktop)

### Projects Gallery
- Masonry-style grid for visual interest
- Project cards with:
  - Featured image placeholder (16:9 aspect ratio)
  - Project title overlay on hover
  - Category badge (Graphic Design / UI Design / UX Design)
  - Brief description revealed on hover
- Minimum 6 project placeholders
- Hover: Subtle scale transform and shadow elevation

### Contact Section
- Centered content with email and social links
- Social icons: Behance, Dribbble, LinkedIn, Instagram (common for designers)
- Large, friendly CTA: "Let's Create Something Amazing"
- Email displayed prominently with copy button
- Resume download button

### Footer
- Simple, centered layout
- Copyright with current year
- "Designed & Built by M.Thanvish Reddy" attribution

---

## Theme Specifications

### Colorful Theme (Dynamic)
**Implementation**: Generate random vibrant color palette on each page load
- **Background**: Subtle animated gradient using 2-3 complementary colors
- **Primary Accent**: Bold, saturated color for CTAs and highlights
- **Secondary Accent**: Complementary color for badges and icons
- **Text**: Dark gray to charcoal on light backgrounds
- **Cards**: Semi-transparent white/glass effect with backdrop blur

**Color Palette Generation Rules**:
- HSL-based: Hue rotates randomly, maintain 70-85% saturation, 50-65% lightness
- Ensure WCAG AA contrast ratios for readability
- Gradient backgrounds: Diagonal (45deg) with smooth transitions

### Minimal Black & White Theme
- **Background**: Pure white (#FFFFFF)
- **Text**: Rich black (#0A0A0A)
- **Accents**: Medium gray (#6B7280) for secondary elements
- **Borders**: Light gray (#E5E7EB) for subtle separations
- **Cards**: White with thin black borders (1px solid)
- **Hover States**: Black background with white text inversion

**Visual Treatment**:
- Strong contrast through typography weight variations
- Generous negative space
- Crisp borders and dividers
- No shadows in this theme - rely on borders for depth

---

## Theme Toggle Mechanics
- Smooth transition: All color properties transition over 300ms
- Toggle button fixed in navigation
- Icon morphs between sun (colorful) and moon (B&W) with rotation
- Save preference to localStorage
- Default to colorful theme on first visit

---

## Images

**Profile/About Section**: 
- Square avatar placeholder (400x400px minimum)
- Can be illustration, photo, or graphic design representation
- Positioned left of bio text on desktop, centered above on mobile

**Project Gallery**:
- 6-9 project thumbnail placeholders (1200x800px recommended)
- Mix of graphic design work, UI mockups, and UX case study visuals
- Use aspect ratio containers (aspect-w-16 aspect-h-9) for consistency

**No Hero Image**: Focus on bold typography and animated gradient backgrounds for visual impact in hero section.

---

## Animation Strategy (Minimal)
- Page load: Staggered fade-up for hero elements only
- Theme toggle: 300ms color transitions across entire page
- Hover states: Subtle scale (1.02-1.05) and shadow elevation
- Scroll indicator: Gentle bounce animation
- NO scroll-triggered animations, parallax, or complex motion