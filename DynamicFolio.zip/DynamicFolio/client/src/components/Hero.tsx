import { useTheme } from '@/contexts/ThemeContext';
import { ArrowDown } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export function Hero() {
  const { mode, palette } = useTheme();

  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="min-h-screen flex items-center justify-center relative overflow-hidden transition-all duration-300"
      style={
        mode === 'colorful'
          ? {
              background: `linear-gradient(135deg, ${palette.gradientFrom} 0%, ${palette.gradientTo} 100%)`,
            }
          : {
              background: 'linear-gradient(135deg, #FFFFFF 0%, #F9FAFB 100%)',
            }
      }
    >
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-12 py-20 text-center">
        <div className="space-y-6 animate-fade-in">
          <Badge
            variant="secondary"
            className="mb-4 text-sm font-medium px-4 py-1.5"
            data-testid="badge-grade"
          >
            12th Grade Student
          </Badge>
          
          <h1
            className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-display font-bold tracking-tight mb-6 transition-all duration-300"
            style={
              mode === 'colorful'
                ? { 
                    color: '#1F2937',
                    textShadow: '0 2px 4px rgba(0,0,0,0.1)'
                  }
                : undefined
            }
            data-testid="text-name"
          >
            M.Thanvish Reddy
          </h1>
          
          <div 
            className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3 text-lg sm:text-xl md:text-2xl mb-8 transition-all duration-300"
            style={mode === 'colorful' ? { color: '#4B5563' } : undefined}
          >
            <span data-testid="text-title-graphic">Graphic Designer</span>
            <span className="hidden sm:block w-1 h-1 rounded-full bg-current" />
            <span data-testid="text-title-ui">UI Designer</span>
            <span className="hidden sm:block w-1 h-1 rounded-full bg-current" />
            <span data-testid="text-title-ux">UX Designer</span>
          </div>
          
          <p 
            className="text-lg md:text-xl max-w-2xl mx-auto leading-relaxed transition-all duration-300" 
            style={mode === 'colorful' ? { color: '#6B7280' } : undefined}
            data-testid="text-hero-description"
          >
            Crafting beautiful digital experiences with a passion for design and innovation.
            Experienced in creating impactful solutions for startups.
          </p>
        </div>
      </div>

      <button
        onClick={scrollToAbout}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce hover-elevate active-elevate-2 p-3 rounded-full transition-all"
        style={mode === 'colorful' ? { backgroundColor: `${palette.primary}20` } : undefined}
        data-testid="button-scroll-down"
        aria-label="Scroll to about section"
      >
        <ArrowDown
          className="h-6 w-6"
          style={mode === 'colorful' ? { color: palette.primary } : undefined}
        />
      </button>
    </section>
  );
}
