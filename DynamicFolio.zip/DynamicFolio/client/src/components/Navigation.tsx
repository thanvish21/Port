import { useState } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { Palette, Minus, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Navigation() {
  const { mode, toggleTheme, palette } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  const navItems = [
    { id: 'about', label: 'About' },
    { id: 'experience', label: 'Experience' },
    { id: 'projects', label: 'Projects' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 md:px-8 lg:px-12 py-4">
          <div className="flex items-center justify-between gap-4">
            <button
              onClick={() => scrollToSection('hero')}
              className="text-lg font-display font-semibold hover-elevate active-elevate-2 px-3 py-1.5 rounded-md transition-all"
              style={mode === 'colorful' ? { color: palette.primary } : undefined}
              data-testid="button-home"
            >
              TR
            </button>
            
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="px-4 py-2 text-sm font-medium hover-elevate active-elevate-2 rounded-md transition-all"
                  data-testid={`button-nav-${item.id}`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <Button
                size="icon"
                variant="ghost"
                onClick={toggleTheme}
                className="transition-all duration-300"
                style={mode === 'colorful' ? { color: palette.primary } : undefined}
                data-testid="button-theme-toggle"
                title={mode === 'colorful' ? 'Switch to minimal theme' : 'Switch to colorful theme'}
              >
                {mode === 'colorful' ? (
                  <Palette className="h-5 w-5 rotate-0 transition-transform duration-300" />
                ) : (
                  <Minus className="h-5 w-5 rotate-90 transition-transform duration-300" />
                )}
              </Button>

              <Button
                size="icon"
                variant="ghost"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden transition-all duration-300"
                data-testid="button-mobile-menu"
              >
                {mobileMenuOpen ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Menu className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 md:hidden bg-background/95 backdrop-blur-lg pt-20 transition-all duration-300"
          data-testid="mobile-menu"
        >
          <div className="flex flex-col items-center gap-2 px-6 py-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="w-full text-center px-6 py-4 text-lg font-medium hover-elevate active-elevate-2 rounded-md transition-all"
                style={mode === 'colorful' ? { color: palette.primary } : undefined}
                data-testid={`button-mobile-${item.id}`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
