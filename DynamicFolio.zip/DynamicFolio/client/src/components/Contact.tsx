import { useTheme } from '@/contexts/ThemeContext';
import { Button } from '@/components/ui/button';
import { SiBehance, SiDribbble, SiLinkedin, SiInstagram } from 'react-icons/si';
import { Mail, FileDown } from 'lucide-react';

export function Contact() {
  const { mode, palette } = useTheme();

  const socials = [
    { name: 'Behance', icon: SiBehance, url: '#', testId: 'link-behance' },
    { name: 'Dribbble', icon: SiDribbble, url: '#', testId: 'link-dribbble' },
    { name: 'LinkedIn', icon: SiLinkedin, url: '#', testId: 'link-linkedin' },
    { name: 'Instagram', icon: SiInstagram, url: '#', testId: 'link-instagram' },
  ];

  return (
    <section 
      id="contact" 
      className="py-20 md:py-32 transition-all duration-300"
      style={
        mode === 'minimal'
          ? { backgroundColor: '#FAFAFA' }
          : { backgroundColor: 'hsl(var(--muted) / 0.3)' }
      }
    >
      <div className="max-w-4xl mx-auto px-6 md:px-8 lg:px-12 text-center">
        <h2
          className="text-4xl md:text-5xl font-display font-semibold mb-8 transition-all duration-300"
          style={mode === 'colorful' ? { color: palette.primary } : undefined}
          data-testid="heading-contact"
        >
          Let's Create Something Amazing
        </h2>

        <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto" data-testid="text-contact-description">
          I'm always excited to collaborate on new projects and innovative ideas.
          Feel free to reach out!
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <Button
            size="lg"
            className="gap-2 transition-all duration-300"
            style={
              mode === 'colorful'
                ? {
                    backgroundColor: palette.primary,
                    color: '#ffffff',
                  }
                : undefined
            }
            data-testid="button-email"
          >
            <Mail className="h-5 w-5" />
            thanvishreddyco@gmail.com
          </Button>

          <Button
            size="lg"
            variant="outline"
            className="gap-2"
            data-testid="button-resume"
          >
            <FileDown className="h-5 w-5" />
            Download Resume
          </Button>
        </div>

        <div className="flex items-center justify-center gap-4 mb-8">
          {socials.map((social) => {
            const Icon = social.icon;
            return (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg hover-elevate active-elevate-2 transition-all duration-300"
                style={
                  mode === 'colorful'
                    ? { backgroundColor: `${palette.primary}20` }
                    : undefined
                }
                data-testid={social.testId}
                aria-label={social.name}
              >
                <Icon
                  className="h-6 w-6 transition-all duration-300"
                  style={mode === 'colorful' ? { color: palette.primary } : undefined}
                />
              </a>
            );
          })}
        </div>

        <div className="pt-12 border-t border-border">
          <p className="text-sm text-muted-foreground" data-testid="text-footer">
            © {new Date().getFullYear()} M.Thanvish Reddy. Designed & Built with passion.
          </p>
        </div>
      </div>
    </section>
  );
}
