import { useTheme } from '@/contexts/ThemeContext';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { User } from 'lucide-react';

export function About() {
  const { mode, palette } = useTheme();

  const skills = [
    'Graphic Design',
    'UI Design',
    'UX Design',
    'Branding',
    'Typography',
    'Prototyping',
    'Figma',
    'Adobe Creative Suite',
    'User Research',
    'Wireframing',
  ];

  return (
    <section 
      id="about" 
      className="py-20 md:py-32 transition-all duration-300"
      style={
        mode === 'minimal'
          ? { backgroundColor: '#FAFAFA' }
          : undefined
      }
    >
      <div className="max-w-7xl mx-auto px-6 md:px-8 lg:px-12">
        <h2
          className="text-4xl md:text-5xl font-display font-semibold mb-16 text-center transition-all duration-300"
          style={mode === 'colorful' ? { color: palette.primary } : undefined}
          data-testid="heading-about"
        >
          About Me
        </h2>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="flex justify-center">
            <Card className="p-12 w-full max-w-sm aspect-square flex items-center justify-center">
              <User
                className="w-32 h-32 transition-all duration-300"
                style={mode === 'colorful' ? { color: palette.primary } : undefined}
                data-testid="icon-avatar"
              />
            </Card>
          </div>

          <div className="space-y-6">
            <p className="text-lg leading-relaxed text-foreground" data-testid="text-about-description">
              I'm a passionate designer currently in 12th grade, dedicated to creating
              meaningful and visually compelling digital experiences. My journey in design
              combines creativity with strategic thinking to solve real-world problems.
            </p>
            
            <p className="text-lg leading-relaxed text-muted-foreground" data-testid="text-about-passion">
              With experience working alongside two innovative startups, I've learned to
              balance aesthetic excellence with functional design. I believe great design
              is invisible—it just works.
            </p>

            <div className="pt-4">
              <h3 className="text-xl font-display font-semibold mb-4" data-testid="heading-skills">
                Skills & Expertise
              </h3>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, index) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="text-sm px-3 py-1.5 hover-elevate transition-all duration-200"
                    style={
                      mode === 'colorful' && index < 3
                        ? {
                            backgroundColor: `${palette.primary}20`,
                            color: palette.primary,
                          }
                        : undefined
                    }
                    data-testid={`badge-skill-${skill.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
