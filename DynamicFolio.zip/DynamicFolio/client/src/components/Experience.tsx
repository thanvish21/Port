import { useTheme } from '@/contexts/ThemeContext';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Briefcase } from 'lucide-react';

export function Experience() {
  const { mode, palette } = useTheme();

  const experiences = [
    {
      company: 'Innovative Tech Startup',
      role: 'UI/UX Designer',
      duration: '2023 - 2024',
      achievements: [
        'Designed user interfaces for web and mobile applications',
        'Conducted user research and created user personas',
        'Collaborated with developers to implement design systems',
      ],
      tools: ['Figma', 'Adobe XD', 'Prototyping', 'User Testing'],
    },
    {
      company: 'Creative Solutions Co.',
      role: 'Graphic Designer',
      duration: '2022 - 2023',
      achievements: [
        'Created brand identity and visual assets for marketing campaigns',
        'Designed social media graphics and promotional materials',
        'Developed consistent branding guidelines and style guides',
      ],
      tools: ['Photoshop', 'Illustrator', 'Branding', 'Social Media'],
    },
  ];

  return (
    <section 
      id="experience" 
      className="py-20 md:py-32 transition-all duration-300"
      style={
        mode === 'minimal'
          ? { backgroundColor: '#FFFFFF' }
          : { backgroundColor: 'hsl(var(--muted) / 0.3)' }
      }
    >
      <div className="max-w-7xl mx-auto px-6 md:px-8 lg:px-12">
        <h2
          className="text-4xl md:text-5xl font-display font-semibold mb-16 text-center transition-all duration-300"
          style={mode === 'colorful' ? { color: palette.primary } : undefined}
          data-testid="heading-experience"
        >
          Experience
        </h2>

        <div className="relative space-y-8 md:space-y-12">
          {mode === 'colorful' && (
            <div
              className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 -translate-x-1/2 hidden md:block"
              style={{ backgroundColor: `${palette.primary}30` }}
            />
          )}
          {mode === 'minimal' && (
            <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-border -translate-x-1/2 hidden md:block" />
          )}

          {experiences.map((exp, index) => (
            <div
              key={index}
              className="relative md:grid md:grid-cols-2 md:gap-8"
            >
              <div className="hidden md:block absolute top-6 left-1/2 -translate-x-1/2 z-10">
                <div
                  className="w-4 h-4 rounded-full border-4 border-background transition-all duration-300"
                  style={
                    mode === 'colorful'
                      ? { backgroundColor: palette.primary }
                      : { backgroundColor: '#000000' }
                  }
                />
              </div>

              <Card
                className={`hover-elevate transition-all duration-300 ${
                  index % 2 === 0 ? 'md:col-start-1' : 'md:col-start-2'
                }`}
                data-testid={`card-experience-${index}`}
              >
                <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="p-3 rounded-lg transition-all duration-300"
                      style={
                        mode === 'colorful'
                          ? { backgroundColor: `${palette.primary}20` }
                          : undefined
                      }
                    >
                      <Briefcase
                        className="h-5 w-5 transition-all duration-300"
                        style={mode === 'colorful' ? { color: palette.primary } : undefined}
                      />
                    </div>
                    <div>
                      <h3 className="text-xl font-display font-semibold" data-testid={`text-company-${index}`}>
                        {exp.company}
                      </h3>
                      <p className="text-sm text-muted-foreground" data-testid={`text-duration-${index}`}>
                        {exp.duration}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p
                    className="font-medium text-lg transition-all duration-300"
                    style={mode === 'colorful' ? { color: palette.secondary } : undefined}
                    data-testid={`text-role-${index}`}
                  >
                    {exp.role}
                  </p>
                  <ul className="space-y-2 text-muted-foreground">
                    {exp.achievements.map((achievement, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-2"
                        data-testid={`text-achievement-${index}-${i}`}
                      >
                        <span className="mt-2 w-1.5 h-1.5 rounded-full bg-muted-foreground flex-shrink-0" />
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap gap-2 pt-2">
                    {exp.tools.map((tool) => (
                      <Badge
                        key={tool}
                        variant="outline"
                        className="text-xs"
                        data-testid={`badge-tool-${index}-${tool.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        {tool}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
