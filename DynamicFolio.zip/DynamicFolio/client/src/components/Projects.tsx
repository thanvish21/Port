import { useTheme } from '@/contexts/ThemeContext';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Palette, Smartphone, Layout } from 'lucide-react';

export function Projects() {
  const { mode, palette } = useTheme();

  const projects = [
    {
      title: 'Brand Identity Design',
      category: 'Graphic Design',
      description: 'Complete brand identity system including logo, color palette, and brand guidelines for a tech startup.',
      icon: Palette,
    },
    {
      title: 'Mobile App UI',
      category: 'UI Design',
      description: 'User interface design for an e-commerce mobile application with focus on seamless user experience.',
      icon: Smartphone,
    },
    {
      title: 'SaaS Dashboard',
      category: 'UX Design',
      description: 'Analytics dashboard with data visualization and user-friendly navigation for business intelligence.',
      icon: Layout,
    },
    {
      title: 'Marketing Campaign',
      category: 'Graphic Design',
      description: 'Visual assets and promotional materials for a social media marketing campaign.',
      icon: Palette,
    },
    {
      title: 'Website Redesign',
      category: 'UI/UX Design',
      description: 'Complete website overhaul with improved user flow and modern aesthetic for better engagement.',
      icon: Layout,
    },
    {
      title: 'Design System',
      category: 'UI Design',
      description: 'Comprehensive design system with reusable components and documentation for scalability.',
      icon: Smartphone,
    },
  ];

  return (
    <section 
      id="projects" 
      className="py-20 md:py-32 transition-all duration-300"
      style={
        mode === 'minimal'
          ? { backgroundColor: '#F5F5F5' }
          : undefined
      }
    >
      <div className="max-w-7xl mx-auto px-6 md:px-8 lg:px-12">
        <h2
          className="text-4xl md:text-5xl font-display font-semibold mb-16 text-center transition-all duration-300"
          style={mode === 'colorful' ? { color: palette.primary } : undefined}
          data-testid="heading-projects"
        >
          Featured Projects
        </h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {projects.map((project, index) => {
            const Icon = project.icon;
            return (
              <Card
                key={index}
                className="group hover-elevate active-elevate-2 cursor-pointer transition-all duration-300 overflow-hidden"
                data-testid={`card-project-${index}`}
              >
                <div
                  className="h-48 flex items-center justify-center transition-all duration-300"
                  style={
                    mode === 'colorful'
                      ? {
                          background: `linear-gradient(135deg, ${palette.gradientFrom}40 0%, ${palette.gradientTo}40 100%)`,
                        }
                      : { backgroundColor: '#F9FAFB' }
                  }
                >
                  <Icon
                    className="w-16 h-16 transition-all duration-300 group-hover:scale-110"
                    style={mode === 'colorful' ? { color: palette.primary } : undefined}
                  />
                </div>
                <CardContent className="p-6 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <h3
                      className="text-xl font-display font-semibold transition-all duration-300"
                      data-testid={`text-project-title-${index}`}
                    >
                      {project.title}
                    </h3>
                  </div>
                  <Badge
                    variant="secondary"
                    className="text-xs"
                    style={
                      mode === 'colorful'
                        ? {
                            backgroundColor: `${palette.secondary}20`,
                            color: palette.secondary,
                          }
                        : undefined
                    }
                    data-testid={`badge-category-${index}`}
                  >
                    {project.category}
                  </Badge>
                  <p className="text-sm text-muted-foreground leading-relaxed" data-testid={`text-project-description-${index}`}>
                    {project.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
