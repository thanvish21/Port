import { createContext, useContext, useEffect, useState, ReactNode } from 'react';

type ThemeMode = 'colorful' | 'minimal';

interface ColorPalette {
  primary: string;
  secondary: string;
  accent: string;
  gradientFrom: string;
  gradientTo: string;
}

interface ThemeContextType {
  mode: ThemeMode;
  palette: ColorPalette;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

function generateRandomPalette(): ColorPalette {
  const hue = Math.floor(Math.random() * 360);
  const complementaryHue = (hue + 180) % 360;
  const analogousHue = (hue + 30) % 360;
  
  const saturation = 70 + Math.random() * 15;
  const lightness = 50 + Math.random() * 15;
  
  return {
    primary: `hsl(${hue}, ${saturation}%, ${lightness}%)`,
    secondary: `hsl(${complementaryHue}, ${saturation}%, ${lightness}%)`,
    accent: `hsl(${analogousHue}, ${saturation - 10}%, ${lightness + 10}%)`,
    gradientFrom: `hsl(${hue}, ${saturation}%, ${lightness}%)`,
    gradientTo: `hsl(${analogousHue}, ${saturation - 5}%, ${lightness + 5}%)`,
  };
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('portfolio-theme');
    return (saved as ThemeMode) || 'colorful';
  });
  
  const [palette, setPalette] = useState<ColorPalette>(() => {
    if (mode === 'colorful') {
      return generateRandomPalette();
    }
    return {
      primary: '#000000',
      secondary: '#6B7280',
      accent: '#374151',
      gradientFrom: '#FFFFFF',
      gradientTo: '#F9FAFB',
    };
  });

  useEffect(() => {
    localStorage.setItem('portfolio-theme', mode);
    
    if (mode === 'colorful') {
      const root = document.documentElement;
      root.style.setProperty('--theme-primary', palette.primary);
      root.style.setProperty('--theme-secondary', palette.secondary);
      root.style.setProperty('--theme-accent', palette.accent);
      root.style.setProperty('--theme-gradient-from', palette.gradientFrom);
      root.style.setProperty('--theme-gradient-to', palette.gradientTo);
    }
  }, [mode, palette]);

  const toggleTheme = () => {
    setMode(prev => {
      const newMode = prev === 'colorful' ? 'minimal' : 'colorful';
      if (newMode === 'colorful') {
        setPalette(generateRandomPalette());
      } else {
        setPalette({
          primary: '#000000',
          secondary: '#6B7280',
          accent: '#374151',
          gradientFrom: '#FFFFFF',
          gradientTo: '#F9FAFB',
        });
      }
      return newMode;
    });
  };

  return (
    <ThemeContext.Provider value={{ mode, palette, toggleTheme }}>
      <div className={mode === 'minimal' ? 'minimal-theme' : 'colorful-theme'}>
        {children}
      </div>
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}
